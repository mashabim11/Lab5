import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details4',
  templateUrl: './product-details4.component.html',
  styleUrls: ['./product-details4.component.css']
})
export class ProductDetails4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
