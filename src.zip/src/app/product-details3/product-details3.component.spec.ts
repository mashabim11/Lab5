// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { ProductDetails3Component } from './product-details3.component';

// describe('ProductDetails3Component', () => {
//   let component: ProductDetails3Component;
//   let fixture: ComponentFixture<ProductDetails3Component>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ ProductDetails3Component ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ProductDetails3Component);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
